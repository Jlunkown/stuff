using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class powerUpGive : MonoBehaviour
{
    public bool hasGun;
    public float givehealthAmount;
    public float giveSpeedAmount;
    public bool inControl;
    public float increaseAtkRate;
}
